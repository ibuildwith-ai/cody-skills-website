---
command: ":cody refresh brownfield"
description: Analyzes an existing codebase (brownfield project), asks the USER targeted questions, and auto-generates the plan phase documents.
---

# BROWNFIELD PROJECT ANALYSIS

### ANNOUNCE TO THE **USER**

- **AGENT** show the **USER** the following:
```
+---------------------------+
BROWNFIELD PROJECT DETECTED
+---------------------------+
```
- Tell the **USER** that you (**AGENT**) detected an existing codebase with no Cody project files.
- Tell the **USER** you will now analyze the project and ask targeted questions to build a complete understanding.

---

## AUTONOMOUS CODEBASE ANALYSIS

You (**AGENT**) will thoroughly examine the existing codebase. Review the following (as applicable):

- Root-level files and folder structure
- Package/dependency files (package.json, requirements.txt, go.mod, Gemfile, etc.)
- Config files (tsconfig, vite.config, tailwind.config, .env.example, docker-compose, etc.)
- Entry points (index.html, main.ts, app.ts, index.js, etc.)
- Source code structure (src/, server/, components/, routes/, pages/, lib/, etc.)
- Database models/schemas if present
- API routes/endpoints if present
- README or any existing documentation

**Skip Cody Product Builder files — they are not part of the application:**
- `cody.json` at the project root. Skip it (Cody Product Builder project configuration).
- The `cody-product-builder/` skill folder, wherever the host agent installed it (for example `.claude/skills/cody-product-builder/`, `.cursor/skills/cody-product-builder/`, or `.github/skills/cody-product-builder/`). Skip it entirely. Other files in `.claude/`, `.cursor/`, or `.github/` may describe the project and should be reviewed.
- The Cody project output folder (the `plan/` and `build/` documents). Skip it; it is Cody's output, not application code.

After your analysis, tell the **USER** what you found. Provide a brief summary of the tech stack, project structure, and what the app appears to do.

---

## USER Q&A

After presenting your initial findings, ask the **USER** targeted questions to fill gaps in your understanding. Focus on product-level knowledge the code cannot reveal.

**[AGENT TODO: Read {{cfReferences}}/knowledge-criteria.md and follow the Knowledge Criteria, Q&A Guidance, and Example Questions defined there.]**

Additional brownfield-specific guidance:
- Some criteria may already be answered by the autonomous analysis (e.g., tech stack constraints, existing features). Confirm those with the **USER** instead of re-asking.
- Focus Q&A on what the code can't reveal (target users, goals, success criteria, etc.).

---

## PRESENT UNDERSTANDING

- Summarize your full understanding of the project back to the **USER**:
  - What you learned from the codebase analysis (tech stack, architecture, existing features)
  - What you learned from the Q&A (target users, goals, success criteria, etc.)
- Ask for explicit approval. **STOP** for **USER APPROVAL**.
- If not approved, continue asking targeted questions and refine until approved.

---

## CREATE PROJECT WORKSPACE

- Ask the **USER**: `What version is your project currently at? (e.g., 1.0.0, 0.5.0)`
- **STOP** and wait for the **USER**.

**[AGENT TODO: Read and execute {{cfReferences}}/create-project-workspace.md with these values: name/description source = what you learned during the codebase analysis and Q&A; version = the version the USER just provided; phase = `"build"`.]**

---

## WRITE BROWNFIELD ANALYSIS

- Copy `{{cfAssets}}/plan/brownfield-analysis.md` to `{{cfPlanPhase}}/brownfield-analysis.md`.
- Update all sections based on what you learned from the codebase analysis and user Q&A.
- Tell the **USER**:
```
I've created the Brownfield Analysis document summarizing my findings.
I stored it at {{cfProject}}/plan/brownfield-analysis.md.
You can review it and make changes to it.
If you did make changes, tell me to "review it".
If you didn't, just say "continue".
```
- **STOP** and wait for the **USER**.
- If the **USER** made changes, re-read the file and acknowledge the changes.
- If the **USER** says "continue", proceed.

---

## AUTO-GENERATE PRD

- **AGENT** show the **USER** the following:
```
+--------------+
GENERATING PRD
+--------------+
```
- Copy from `{{cfAssets}}/plan/prd.md` into `{{cfPlanPhase}}`.
- Review the brownfield-analysis.md document and use it to generate and update the prd.md document.
- Tell the **USER** to review the PRD document.
- **STOP** and wait for the **USER**.
- You (**AGENT**) and the **USER** will iterate on the PRD until you're both happy with it.

---

## AUTO-GENERATE PLAN

- **AGENT** show the **USER** the following:
```
+----------------+
GENERATING PLAN
+----------------+
```
- Once the **USER** approves the PRD, copy from `{{cfAssets}}/plan/plan.md` into `{{cfPlanPhase}}`.
- Review the prd.md document and the brownfield-analysis.md document and use them to generate and update the plan.md document.
- Tell the **USER** to review the Plan document.
- **STOP** and wait for the **USER**.
- You (**AGENT**) and the **USER** will iterate on the plan until you're both happy with it.

---

## PLAN PHASE COMPLETE

- **AGENT** show the **USER** the following:
```
+--------------------+
PLAN PHASE : COMPLETED
+--------------------+
```
- Tell the **USER** the plan phase has ended and if they want to start building, they can just type `:cody build` to create the feature backlog.
- Stop here.
